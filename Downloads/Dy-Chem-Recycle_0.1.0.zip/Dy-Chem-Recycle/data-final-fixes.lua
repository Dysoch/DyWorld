


for _,type in pairs({"item", "fluid", "module", "ammo", "capsule", "tool", "gun", "armor", "rail-planner", "repair-tool"}) do
	for _,v in pairs(data.raw[type]) do
		if not v.Chemical_Formula then
			v.Chemical_Formula = "none"
		end
	end
end

for _,type in pairs({"item", "fluid", "module", "ammo", "capsule", "tool", "gun", "armor", "rail-planner", "repair-tool"}) do
	for _,v in pairs(data.raw[type]) do
		if v.Chemical_Formula then
data:extend(
{
  {
    type = "recipe",
    name = "chem-recycle-"..v.name,
	category = "chemical-recycling",
	main_product = v.name,
	allow_decomposition = false,
	hide_from_player_crafting = true,
	hide_from_stats = true,
    normal =
    {
      ingredients =
      {
        {type = v.type == "fluid" and "fluid" or "item", name = v.name, amount = v.type == "fluid" and 10 or 1},
      },
      results = 
      {
        {type = v.type == "fluid" and "fluid" or "item", name = v.name, amount = 0},
      },
	  energy_required = 10,
	  main_product = v.name,
	  enabled = false,
	  allow_decomposition = false,
	  hide_from_player_crafting = true,
	  hide_from_stats = true,
    },
  },
})
			if string.find(v.Chemical_Formula, "S-", 1, true) then
				if data.raw.item["sulfur"] then
					local result = {type = "item", name = "sulfur", amount_min = 0, amount_max = 3, probability = 0.1}
					table.insert(data.raw.recipe["chem-recycle-"..v.name].normal.results, result)
				end
			end
			if string.find(v.Chemical_Formula, "Cu-", 1, true) then
				if data.raw.tool["copper-ore-impure"] then
					local result = {type = "item", name = "copper-ore-impure", amount_min = 0, amount_max = 3, probability = 0.1}
					table.insert(data.raw.recipe["chem-recycle-"..v.name].normal.results, result)
				else
					local result = {type = "item", name = "copper-ore", amount_min = 0, amount_max = 3, probability = 0.1}
					table.insert(data.raw.recipe["chem-recycle-"..v.name].normal.results, result)
				end
			end
			if string.find(v.Chemical_Formula, "Fe-", 1, true) then
				if data.raw.tool["iron-ore-impure"] then
					local result = {type = "item", name = "iron-ore-impure", amount_min = 0, amount_max = 3, probability = 0.1}
					table.insert(data.raw.recipe["chem-recycle-"..v.name].normal.results, result)
				else
					local result = {type = "item", name = "iron-ore", amount_min = 0, amount_max = 3, probability = 0.1}
					table.insert(data.raw.recipe["chem-recycle-"..v.name].normal.results, result)
				end
			end
			if string.find(v.Chemical_Formula, "U-", 1, true) then
				if data.raw.tool["uranium-ore-impure"] then
					local result = {type = "item", name = "uranium-ore-impure", amount_min = 0, amount_max = 3, probability = 0.1}
					table.insert(data.raw.recipe["chem-recycle-"..v.name].normal.results, result)
				else
					local result = {type = "item", name = "uranium-ore", amount_min = 0, amount_max = 3, probability = 0.1}
					table.insert(data.raw.recipe["chem-recycle-"..v.name].normal.results, result)
				end
			end
			if string.find(v.Chemical_Formula, "C-", 1, true) or string.find(v.Chemical_Formula, "C1-", 1, true) then
				if data.raw.item["carbon"] then
					local result = {type = "item", name = "carbon", amount_min = 0, amount_max = 3, probability = 0.1}
					table.insert(data.raw.recipe["chem-recycle-"..v.name].normal.results, result)
				else
					local result = {type = "item", name = "coal", amount_min = 0, amount_max = 3, probability = 0.1}
					table.insert(data.raw.recipe["chem-recycle-"..v.name].normal.results, result)
				end
			end
			if string.find(v.Chemical_Formula, "C2-", 1, true) then
				if data.raw.item["carbon"] then
					local result = {type = "item", name = "carbon", amount_min = 0, amount_max = 6, probability = 0.1}
					table.insert(data.raw.recipe["chem-recycle-"..v.name].normal.results, result)
				else
					local result = {type = "item", name = "coal", amount_min = 0, amount_max = 6, probability = 0.1}
					table.insert(data.raw.recipe["chem-recycle-"..v.name].normal.results, result)
				end
			end
			if data.raw.fluid["oxygen"] then
				if string.find(v.Chemical_Formula, "O-", 1, true) then
					local result = {type = "fluid", name = "oxygen", amount_min = 0, amount_max = 10, probability = 0.1}
					table.insert(data.raw.recipe["chem-recycle-"..v.name].normal.results, result)
				elseif string.find(v.Chemical_Formula, "O2-", 1, true) then
					local result = {type = "fluid", name = "oxygen", amount_min = 0, amount_max = 20, probability = 0.1}
					table.insert(data.raw.recipe["chem-recycle-"..v.name].normal.results, result)
				elseif string.find(v.Chemical_Formula, "O3-", 1, true) then
					local result = {type = "fluid", name = "oxygen", amount_min = 0, amount_max = 30, probability = 0.1}
					table.insert(data.raw.recipe["chem-recycle-"..v.name].normal.results, result)
				elseif string.find(v.Chemical_Formula, "O4-", 1, true) then
					local result = {type = "fluid", name = "oxygen", amount_min = 0, amount_max = 40, probability = 0.1}
					table.insert(data.raw.recipe["chem-recycle-"..v.name].normal.results, result)
				elseif string.find(v.Chemical_Formula, "O5-", 1, true) then
					local result = {type = "fluid", name = "oxygen", amount_min = 0, amount_max = 50, probability = 0.1}
					table.insert(data.raw.recipe["chem-recycle-"..v.name].normal.results, result)
				end
			end
			if string.find(v.Chemical_Formula, "Naphtha-", 1, true) then
				if data.raw.item["naphtha"] then
					local result = {type = "item", name = "naphtha", amount_min = 0, amount_max = 3, probability = 0.1}
					table.insert(data.raw.recipe["chem-recycle-"..v.name].normal.results, result)
				end
			end
			if not data.raw.technology["chemical-recycling-1"] then
				data.raw.recipe["chem-recycle-"..v.name].normal.enabled = true
			else
				local AMOUNT = -1
				for k,v in pairs(data.raw.recipe["chem-recycle-"..v.name].normal.results) do
					AMOUNT = AMOUNT + 1
				end
				DyWorld_Add_To_Tech("chemical-recycling-"..(AMOUNT >= 1 and AMOUNT or 1), "chem-recycle-"..v.name)
			end
		end
	end
end