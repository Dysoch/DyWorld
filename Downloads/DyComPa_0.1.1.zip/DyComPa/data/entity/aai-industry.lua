


local Hidden = "hidden"

data.raw["burner-generator"]["burner-turbine"].burner.fuel_categories = {"carbon"}

--[[if data.raw.item["burner-lab"].flags then
	table.insert(data.raw.item["burner-lab"].flags, Hidden)
end

if data.raw.item["burner-assembling-machine"].flags then
	table.insert(data.raw.item["burner-assembling-machine"].flags, Hidden)
end

if data.raw.item["burner-lab"].flags then
	table.insert(data.raw.item["burner-lab"].flags, Hidden)
end]]

