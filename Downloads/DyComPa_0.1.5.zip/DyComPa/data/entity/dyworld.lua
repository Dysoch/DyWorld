




data.raw["rocket-silo"]["rocket-silo-1"].rocket_result_inventory_size = 4
data.raw["rocket-silo"]["rocket-silo-2"].rocket_result_inventory_size = 10
data.raw["rocket-silo"]["rocket-silo-3"].rocket_result_inventory_size = 20
data.raw["rocket-silo"]["rocket-silo-4"].rocket_result_inventory_size = 40