


if not data.raw.item["se-core-fragment-se-vitamelange"] then
DyDS_Add_Item({
	name = "se-core-fragment-se-vitamelange",
	stack_size = 1000,
	subgroup = DyDs.."0-resource-1",
})
end