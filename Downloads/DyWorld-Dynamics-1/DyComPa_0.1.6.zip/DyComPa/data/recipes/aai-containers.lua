




data.raw.recipe["aai-strongbox"].ingredients = nil
data.raw.recipe["aai-strongbox"].normal =
    {
      ingredients =
      {
        {type = "item", name = "bronze-plate", amount = 40},
      },
      result = "aai-strongbox",
	  result_count = 1,
	  energy_required = 2,
	  enabled = false,
    }