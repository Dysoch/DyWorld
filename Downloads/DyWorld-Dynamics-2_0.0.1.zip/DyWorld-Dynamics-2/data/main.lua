

local core = "data.core."


-- Core --
require(core.."main")

-- Logistics --
require("data.logistics.data")