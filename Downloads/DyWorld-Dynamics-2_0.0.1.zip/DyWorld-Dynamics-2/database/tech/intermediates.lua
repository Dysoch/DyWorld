


DyWorld_2_Intermediates_Tech = {
    --[""] = {},

    ["metallurgy"] = {},
    ["combat"] = {},
    ["intermediates"] = {},
    ["biological"] = {},
    ["infrastructure"] = {},
    ["space-technology"] = {"metallurgy", "combat", "intermediates", "biological", "infrastructure"},
}