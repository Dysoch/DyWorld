data:extend({
	{
		type = "custom-input",
		name = "DyWorld_Personal_GUI_Key",
		key_sequence = "CONTROL + A",
	},
	-- TEST KEY BINDINGS
})