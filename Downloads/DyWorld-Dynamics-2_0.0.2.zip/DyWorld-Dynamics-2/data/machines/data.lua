
local machine = "data.machines."


require(machine.. "data.greenhouse")
--[[
require(machine.. "data.air-filter")
require(machine.. "data.assemblers")
require(machine.. "data.blast-furnace")
require(machine.. "data.bloomery")
require(machine.. "data.boilers")
require(machine.. "data.caster")
require(machine.. "data.gas-engine")
require(machine.. "data.gas-extractor")
require(machine.. "data.grinder")
require(machine.. "data.kiln-basic")
require(machine.. "data.labs")
require(machine.. "data.mining-drills")
require(machine.. "data.oil-extractor")
require(machine.. "data.power-poles")
require(machine.. "data.radars")
require(machine.. "data.recycler")
require(machine.. "data.rocket-silo")
require(machine.. "data.single-recipe-machines")
require(machine.. "data.steam-engines")
require(machine.. "data.storage-small")
require(machine.. "data.thermo-centrifuge")
require(machine.. "data.treefarms")
]]