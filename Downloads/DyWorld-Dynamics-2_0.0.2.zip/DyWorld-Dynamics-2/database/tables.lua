
Dy_Tier_Speeds = {
	[1] = 15,
	[2] = 30,
	[3] = 60,
	[4] = 120,
	[5] = 240,
}

Dy_Metal_Table = {
    ["iron"] = 1,
    ["copper"] = 1,
    ["tin"] = 1,
    ["lead"] = 2,
    ["zinc"] = 2,
    ["aluminium"] = 2,
    ["silver"] = 3,
    ["gold"] = 3,
}