


DyWorld_2_Biological_Tech = {
    --[""] = {},

    ["metallurgy"] = {},
    ["combat"] = {},
    ["intermediates"] = {},
    ["biological"] = {},
    ["infrastructure"] = {},
    ["space-technology"] = {"metallurgy", "combat", "intermediates", "biological", "infrastructure"},
}