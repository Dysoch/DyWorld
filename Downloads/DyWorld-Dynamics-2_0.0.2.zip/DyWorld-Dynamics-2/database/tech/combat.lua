


DyWorld_2_Combat_Tech = {
    --[""] = {"combat"},

    ["equipment-1"] = {"combat"},
    ["military"] = {"combat"},
    ["military-2"] = {"military"},
    ["military-3"] = {"military-2"},
    ["military-4"] = {"military-3"},
    ["military-5"] = {"military-4"},
}