


DyWorld_2_Infrastructure_Tech = {
    --[""] = {"infrastructure"},

    ["logistics"] = {"infrastructure"},
    ["logistics-2"] = {"logistics"},
    ["logistics-3"] = {"logistics-2"},
    ["logistics-4"] = {"logistics-3"},
    ["logistics-5"] = {"logistics-4"},

    ["power"] = {"infrastructure"},
    ["power-2"] = {"power"},
    ["power-3"] = {"power-2"},
    ["power-4"] = {"power-3"},
    ["power-5"] = {"power-4"},

    ["transportation"] = {"logistics"},
    ["transportation-2"] = {"transportation", "logistics-3"},
    ["transportation-3"] = {"transportation-2", "logistics-5"},
}