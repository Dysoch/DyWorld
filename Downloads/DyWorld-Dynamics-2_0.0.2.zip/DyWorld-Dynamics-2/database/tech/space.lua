


DyWorld_2_Space_Tech = {
    --[""] = {},

    ["metallurgy"] = {},
    ["combat"] = {},
    ["intermediates"] = {},
    ["biological"] = {},
    ["infrastructure"] = {},
    ["space-technology"] = {"metallurgy", "combat", "intermediates", "biological", "infrastructure"},
}