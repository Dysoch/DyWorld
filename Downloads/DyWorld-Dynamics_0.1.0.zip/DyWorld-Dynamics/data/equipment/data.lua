

require(DyDs_data_equipment.."recipes.nanobot")
require(DyDs_data_equipment.."recipes.base")