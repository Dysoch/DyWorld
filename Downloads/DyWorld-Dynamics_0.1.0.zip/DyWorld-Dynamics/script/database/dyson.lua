



Dyson_Network_Swarm  = {
	["advanced-asteroid-miner-tin"] = 0.1,
	["advanced-asteroid-miner-iron"] = 0.1,
	["advanced-asteroid-miner-copper"] = 0.1,
	["advanced-asteroid-miner-stone"] = 0.1,
	["advanced-asteroid-miner-titanium"] = 0.1,
	["advanced-asteroid-miner-coal"] = 0.1,
	["advanced-asteroid-miner-magnesium"] = 0.1,
	["advanced-asteroid-miner-aluminium"] = 0.1,
	["advanced-asteroid-miner-gold"] = 0.1,
	["advanced-asteroid-miner-lead"] = 0.1,
	["advanced-asteroid-miner-silver"] = 0.1,
	["advanced-asteroid-miner-uranium"] = 0.1,
	["basic-dyson-satellite-1"] = 0.5,
	["basic-dyson-satellite-2"] = 1,
	["basic-dyson-satellite-3"] = 2.5,
	["basic-dyson-satellite-4"] = 5,
	["basic-dyson-satellite-5"] = 10,
	["advanced-dyson-satellite-1"] = 50,
	["advanced-dyson-satellite-2"] = 200,
	["advanced-dyson-satellite-3"] = 1000,
	["advanced-dyson-satellite-4"] = 5000,
	["advanced-dyson-satellite-5"] = 10000,
}

Dyson_Network_Sphere  = {
	["basic-dyson-sphere-comp-1"] = 5,
	["basic-dyson-sphere-comp-2"] = 10,
	["basic-dyson-sphere-comp-3"] = 25,
	["basic-dyson-sphere-comp-4"] = 50,
	["basic-dyson-sphere-comp-5"] = 100,
	["advanced-dyson-sphere-comp-1"] = 500,
	["advanced-dyson-sphere-comp-2"] = 2000,
	["advanced-dyson-sphere-comp-3"] = 10000,
	["advanced-dyson-sphere-comp-4"] = 50000,
	["advanced-dyson-sphere-comp-5"] = 100000,
}
