


--@todo Add Chemical Formula Cables
  
DyDS_Add_Item({
	name = "copper-cable",
	icon = data.raw.item["copper-cable"].icon,
	order = "copper-cable",
	stack_size = 500,
	subgroup = DyDs.."material-2",
})