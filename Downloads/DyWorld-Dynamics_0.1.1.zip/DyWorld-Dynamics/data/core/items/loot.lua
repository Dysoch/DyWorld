


  
DyDS_Add_Item({
	name = "enemy-corpse",
    icon = DyDs_path_icon.."enemy-corpse.png",
	order = "enemy-corpse",
	stack_size = 500,
	subgroup = DyDs.."z-loot",
})
  
DyDS_Add_Tool({
	name = "exotic-partical",
    icon = DyDs_path_icon.."enemy-corpse.png",
	order = "exotic-partical",
	stack_size = 100000,
	durability = 1,
	subgroup = DyDs.."z-loot",
})