

require(DyDs_data_equipment.."base.shield-1")
require(DyDs_data_equipment.."base.shield-2")
require(DyDs_data_equipment.."base.shield-3")
require(DyDs_data_equipment.."base.exo-1")
require(DyDs_data_equipment.."base.solar")
require(DyDs_data_equipment.."base.fission")