



require(DyDs_data_nuclear.."reactor.fission")
require(DyDs_data_nuclear.."reactor.fusion")