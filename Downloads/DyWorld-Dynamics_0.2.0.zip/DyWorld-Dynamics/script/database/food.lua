



Food_Values  = {

	---- Both -----
	
	["cooked-fish"] = {Food = 25, Water = 50},
	["cooked-fish-pike-filet"] = {Food = 50, Water = 75},
	["cooked-fish-salmon-filet"] = {Food = 65, Water = 60},
	
	---- Water -----
	
	["bottle-dirty-water"] = {Water = 100},
	["bottle-clean-water"] = {Water = 200},
	["bottle-mineral-water"] = {Water = 350},
	
	---- Food -----
	
	["carrot"] = {Food = 80},
	["cooked-meat"] = {Food = 250, Water = -50},
	
}

Medpack_Values  = {	
	["basic-med-pack"] = 50,
	["med-pack"] = 100,
	["se-med-pack"] = 50,
	["se-med-pack-2"] = 100,
	["se-med-pack-3"] = 200,
	["se-med-pack-4"] = 400,
}
