


require(DyDs_data_equipment.. "data-final")
require(DyDs_data_tech.. "data")
require("data.core.templates.canisters")


