



Space_Mining  = {
	["advanced-asteroid-miner-tin"] = {Ore = "tin"},
	["advanced-asteroid-miner-iron"] = {Ore = "iron"},
	["advanced-asteroid-miner-copper"] = {Ore = "copper"},
	["advanced-asteroid-miner-stone"] = {Ore = "stone"},
	["advanced-asteroid-miner-titanium"] = {Ore = "titanium"},
	["advanced-asteroid-miner-coal"] = {Ore = "coal"},
	["advanced-asteroid-miner-magnesium"] = {Ore = "magnesium"},
	["advanced-asteroid-miner-aluminium"] = {Ore = "aluminium"},
	["advanced-asteroid-miner-gold"] = {Ore = "gold"},
	["advanced-asteroid-miner-lead"] = {Ore = "lead"},
	["advanced-asteroid-miner-silver"] = {Ore = "silver"},
	["advanced-asteroid-miner-uranium"] = {Ore = "uranium"},
}
