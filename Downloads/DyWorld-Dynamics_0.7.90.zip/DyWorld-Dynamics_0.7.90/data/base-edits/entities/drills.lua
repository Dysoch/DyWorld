




data.raw["mining-drill"]["burner-mining-drill"].resource_categories = {"resource-solid-tier-0", "resource-solid-tier-1"}
data.raw["mining-drill"]["electric-mining-drill"].resource_categories = {"resource-solid-tier-0", "resource-solid-tier-1", "resource-solid-tier-2"}
data.raw["mining-drill"]["burner-mining-drill"].energy_source.fuel_category = "carbon"