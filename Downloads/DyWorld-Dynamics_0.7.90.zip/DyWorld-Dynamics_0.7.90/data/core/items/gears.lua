


  
DyDS_Add_Item({
	name = "iron-gear",
    icons = {{icon = data.raw.item["iron-gear-wheel"].icon}},
	order = "iron-gear",
	stack_size = 500,
	subgroup = DyDs.."material-2",
})

DyDS_Add_Item({
	name = "bronze-gear",
    icons = {{icon = data.raw.item["iron-gear-wheel"].icon, tint = {r=126, g=112, b=109}}},
	order = "bronze-gear",
	stack_size = 500,
	subgroup = DyDs.."material-1",
})