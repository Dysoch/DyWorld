
-- Tier 1 --
require(DyDs_data_tech.. "tier-1.metal-research") -- Core adder

-- Tier 2 --
require(DyDs_data_tech.. "tier-2.chemical-research") -- Core adder


require(DyDs_data_tech.. "recipes")
