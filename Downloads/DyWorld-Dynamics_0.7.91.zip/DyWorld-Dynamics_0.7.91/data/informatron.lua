
informatron_make_image("small_biter_1", "__DyWorld-Dynamics__/graphics/informatron/small_biter.png", 169, 114) 
informatron_make_image("small_spitter_1", "__DyWorld-Dynamics__/graphics/informatron/small_spitter.png", 215, 118) 
informatron_make_image("medium_biter_1", "__DyWorld-Dynamics__/graphics/informatron/medium_biter.png", 169, 114) 
informatron_make_image("medium_spitter_1", "__DyWorld-Dynamics__/graphics/informatron/medium_spitter.png", 215, 118) 
informatron_make_image("big_biter_1", "__DyWorld-Dynamics__/graphics/informatron/big_biter.png", 189, 134) 
informatron_make_image("big_spitter_1", "__DyWorld-Dynamics__/graphics/informatron/big_spitter.png", 215, 118) 
informatron_make_image("behemoth_biter_1", "__DyWorld-Dynamics__/graphics/informatron/behemoth_biter.png", 210, 154) 
informatron_make_image("behemoth_spitter_1", "__DyWorld-Dynamics__/graphics/informatron/behemoth_spitter.png", 215, 118) 