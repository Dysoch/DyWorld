
data.raw["utility-constants"]["default"].main_menu_background_image_location = "__DyWorld__/graphics/dyworldlogo.jpg"

-- Core Modules --
require("data.prefix")
require(DyDs_data_base_edits.. "data")
require(DyDs_data_core.. "data")
require(DyDs_data_resources.. "data")
require(DyDs_data_machines.. "data")
require(DyDs_data_warfare.. "data")
require(DyDs_data_logistics.. "data")

