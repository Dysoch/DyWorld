




data.raw["container"]["crash-site-spaceship"].max_health = 500000
data.raw["container"]["crash-site-spaceship"].inventory_size = 50
data.raw["container"]["crash-site-spaceship"].minable = nil

data.raw["container"]["crash-site-spaceship-wreck-big-1"].max_health = 50000
data.raw["container"]["crash-site-spaceship-wreck-big-1"].inventory_size = 10
data.raw["container"]["crash-site-spaceship-wreck-big-1"].minable = nil

data.raw["container"]["crash-site-spaceship-wreck-big-2"].max_health = 50000
data.raw["container"]["crash-site-spaceship-wreck-big-2"].inventory_size = 10
data.raw["container"]["crash-site-spaceship-wreck-big-2"].minable = nil

data.raw["container"]["crash-site-spaceship-wreck-medium-1"].max_health = 25000
data.raw["container"]["crash-site-spaceship-wreck-medium-1"].inventory_size = 5
data.raw["container"]["crash-site-spaceship-wreck-medium-1"].minable = nil

data.raw["container"]["crash-site-spaceship-wreck-medium-2"].max_health = 25000
data.raw["container"]["crash-site-spaceship-wreck-medium-2"].inventory_size = 5
data.raw["container"]["crash-site-spaceship-wreck-medium-2"].minable = nil

data.raw["container"]["crash-site-spaceship-wreck-medium-3"].max_health = 25000
data.raw["container"]["crash-site-spaceship-wreck-medium-3"].inventory_size = 5
data.raw["container"]["crash-site-spaceship-wreck-medium-3"].minable = nil

data.raw["simple-entity-with-owner"]["crash-site-spaceship-wreck-small-1"].max_health = 5000
data.raw["simple-entity-with-owner"]["crash-site-spaceship-wreck-small-1"].minable = nil

data.raw["simple-entity-with-owner"]["crash-site-spaceship-wreck-small-2"].max_health = 5000
data.raw["simple-entity-with-owner"]["crash-site-spaceship-wreck-small-2"].minable = nil

data.raw["simple-entity-with-owner"]["crash-site-spaceship-wreck-small-3"].max_health = 5000
data.raw["simple-entity-with-owner"]["crash-site-spaceship-wreck-small-3"].minable = nil

data.raw["simple-entity-with-owner"]["crash-site-spaceship-wreck-small-4"].max_health = 5000
data.raw["simple-entity-with-owner"]["crash-site-spaceship-wreck-small-4"].minable = nil

data.raw["simple-entity-with-owner"]["crash-site-spaceship-wreck-small-5"].max_health = 5000
data.raw["simple-entity-with-owner"]["crash-site-spaceship-wreck-small-5"].minable = nil

data.raw["simple-entity-with-owner"]["crash-site-spaceship-wreck-small-6"].max_health = 5000
data.raw["simple-entity-with-owner"]["crash-site-spaceship-wreck-small-6"].minable = nil