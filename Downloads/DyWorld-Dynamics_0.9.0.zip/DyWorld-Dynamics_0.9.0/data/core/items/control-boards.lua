


  
DyDS_Add_Item({
	name = "control-board-1",
    icon = DyDs_path_icon.."control-board-1.png",
	order = "copper-cable",
	stack_size = 500,
	subgroup = DyDs.."material-1",
})
  
DyDS_Add_Item({
	name = "control-board-2",
    icon = DyDs_path_icon.."control-board-2.png",
	order = "copper-cable",
	stack_size = 500,
	subgroup = DyDs.."material-2",
})
  
DyDS_Add_Item({
	name = "control-board-3",
    icon = DyDs_path_icon.."control-board-3.png",
	order = "copper-cable",
	stack_size = 500,
	subgroup = DyDs.."material-3",
})
  
DyDS_Add_Item({
	name = "control-board-4",
    icon = DyDs_path_icon.."control-board-4.png",
	order = "copper-cable",
	stack_size = 500,
	subgroup = DyDs.."material-4",
})
  
DyDS_Add_Item({
	name = "control-board-5",
    icon = DyDs_path_icon.."control-board-5.png",
	order = "copper-cable",
	stack_size = 500,
	subgroup = DyDs.."material-5",
})