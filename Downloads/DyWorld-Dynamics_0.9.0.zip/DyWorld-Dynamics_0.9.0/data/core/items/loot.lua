


  
DyDS_Add_Item({
	name = "enemy-corpse",
    icon = DyDs_path_icon.."enemy-corpse.png",
	order = "enemy-corpse",
	stack_size = 500,
	subgroup = DyDs.."z-loot",
})