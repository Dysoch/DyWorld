
-- Tier 1 --
require(DyDs_data_logistics.. "tier-1.pipes")
require(DyDs_data_logistics.. "tier-1.burner-inserter")
require(DyDs_data_logistics.. "tier-1.basic-inserter")
require(DyDs_data_logistics.. "tier-1.basic-splitter")
require(DyDs_data_logistics.. "tier-1.basic-loader")
require(DyDs_data_logistics.. "tier-1.basic-transport-belt")
require(DyDs_data_logistics.. "tier-1.basic-underground-belt")

