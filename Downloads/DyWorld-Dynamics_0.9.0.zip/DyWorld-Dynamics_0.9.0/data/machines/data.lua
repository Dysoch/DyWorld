
-- Tier 1 --
require(DyDs_data_machines.. "tier-1.kiln-basic")
require(DyDs_data_machines.. "tier-1.storage-small")
require(DyDs_data_machines.. "tier-1.basic-burner-drill")
require(DyDs_data_machines.. "tier-1.basic-drill")
require(DyDs_data_machines.. "tier-1.basic-treefarm")
require(DyDs_data_machines.. "tier-1.burner-assembler")
require(DyDs_data_machines.. "tier-1.basic-assembler")
require(DyDs_data_machines.. "tier-1.lab-1")
require(DyDs_data_machines.. "tier-1.basic-boiler")
require(DyDs_data_machines.. "tier-1.basic-steam-engine")
require(DyDs_data_machines.. "tier-1.basic-power-pole")

