
-- Ammo --
require(DyDs_data_warfare.. "ammo.9mm")
require(DyDs_data_warfare.. "ammo.artillery-shell-atomic")

-- Ammo --
require(DyDs_data_warfare.. "armor.basic")

-- Gun --
require(DyDs_data_warfare.. "gun.pistol")

-- Gun --
require(DyDs_data_warfare.. "wall.basic")

-- Gun --
require(DyDs_data_warfare.. "turret.ballistic")