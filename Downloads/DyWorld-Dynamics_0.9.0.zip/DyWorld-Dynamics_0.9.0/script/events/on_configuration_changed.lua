


function Event_on_configuration_changed()

end