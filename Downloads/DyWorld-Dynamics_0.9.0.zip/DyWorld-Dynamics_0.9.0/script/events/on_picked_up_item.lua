


function Event_on_picked_up_item(event)
	local player = game.players[event.player_index]
	local force = player.force
	
end