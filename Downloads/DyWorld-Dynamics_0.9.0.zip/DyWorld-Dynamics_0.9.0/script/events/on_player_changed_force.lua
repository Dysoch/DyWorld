


function Event_on_player_changed_force(event)
	local player = game.players[event.player_index]
	local force = player.force
	
end