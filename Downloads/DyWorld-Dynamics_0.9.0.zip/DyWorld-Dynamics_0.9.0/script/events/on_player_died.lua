


function Event_on_player_died(event)
	local player = game.players[event.player_index]
	local force = player.force
	
end