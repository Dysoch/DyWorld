


function Event_on_player_joined_game(event)
	local player = game.players[event.player_index]
	local force = player.force
	
end