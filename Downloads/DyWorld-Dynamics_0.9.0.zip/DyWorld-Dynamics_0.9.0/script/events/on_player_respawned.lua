


function Event_on_player_respawned(event)
	local player = game.players[event.player_index]
	local force = player.force
	--if gui.name == "button_yes_items" then
	
end