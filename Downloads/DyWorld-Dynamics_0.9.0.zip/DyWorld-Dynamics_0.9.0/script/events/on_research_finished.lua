


function Event_on_research_finished(event)
	
end