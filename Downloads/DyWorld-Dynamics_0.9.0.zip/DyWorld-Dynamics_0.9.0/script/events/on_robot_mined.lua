


function Event_on_robot_mined(event)

end