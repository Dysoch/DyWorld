


function Event_on_rocket_launched(event)
	
end