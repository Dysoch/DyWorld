


function DyDs_GUI_Toggle(player, id)
	Main_GUI(player, id)
end
