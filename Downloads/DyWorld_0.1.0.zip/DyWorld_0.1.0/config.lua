module("config")

Debug = false
-- Debug, mostly used by Dysoch to read game info. No need to enable this!

Hell = false 
-- Enable this if you want a awesome, inferno like world. Fire and Explosions everywhere!
-- NOTE: This is very demanding on the system, so make sure your system is strong enough to handle it!!!!!!!!!!