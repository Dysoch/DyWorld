data:extend(
{
  {
    type = "noise-layer",
    name = "lava"
  },
  {
    type = "noise-layer",
    name = "deeplava"
  },
}
)
