
require("data.power.accumulator.accumulator-normal")
require("data.power.solar.solar-normal")