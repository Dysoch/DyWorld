require "data/prefix"

--[[for k, v in pairs(data.raw.resource) do
	v.minable.hardness = v.minable.hardness*2
end

data.raw.resource["crude-oil"].minable.hardness = 1]]--