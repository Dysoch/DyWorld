require "data/prefix"

data.raw.recipe["iron-plate"].ingredients = {{"iron-ore", 2}}
data.raw.recipe["copper-plate"].ingredients = {{"copper-ore", 2}}
data.raw.recipe["tin-plate"].ingredients = {{"tin-ore", 2}}
data.raw.recipe["gold-plate"].ingredients = {{"gold-ore", 2}}
data.raw.recipe["silver-plate"].ingredients = {{"silver-ore", 2}}
data.raw.recipe["lead-plate"].ingredients = {{"lead-ore", 2}}
data.raw.recipe["chromium-plate"].ingredients = {{"chromium-ore", 2}}
data.raw.recipe["tungsten-plate"].ingredients = {{"tungsten-ore", 2}}
data.raw.recipe["cadmium-plate"].ingredients = {{"cadmium-ore", 2}}
data.raw.recipe["steel-plate"].ingredients = {{"iron-plate", 8}}