require "data/prefix"



data.raw.recipe["iron-axe"].hidden = true
data.raw.recipe["steel-axe"].hidden = true
data.raw.recipe["electric-mining-drill"].hidden = true
