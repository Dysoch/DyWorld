

data.raw["solar-panel"]["solar-panel"].localised_name = {"edits-name.solar-panel"}