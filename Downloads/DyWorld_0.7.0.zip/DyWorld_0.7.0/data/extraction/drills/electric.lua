require "data/prefix"
	
for k,v in pairs(Material_Table) do
	if v.Name == "rubber" then
	
	else
		DyWorld_Mining_Drills_Electric(v)
	end
end