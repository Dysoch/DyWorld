require "data/prefix"
	
for k,v in pairs(Material_Table) do
	DyWorld_Storage_Tanks(v)
end