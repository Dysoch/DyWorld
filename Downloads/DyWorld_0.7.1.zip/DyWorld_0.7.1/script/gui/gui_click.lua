module("gui_click", package.seeall)

function onClick(event)
	local player = game.players[event.player_index]
	local force = player.force
	local name = event.element.name
	if name == "" then
    
	elseif name == "" then
           
	end
end