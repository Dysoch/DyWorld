require "data/prefix"



data.raw.item["burner-inserter"].subgroup = dy.."inserter-base"

