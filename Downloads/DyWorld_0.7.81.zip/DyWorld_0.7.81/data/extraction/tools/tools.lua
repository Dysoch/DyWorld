require "data/prefix"
	
for k,v in pairs(Material_Table) do
	DyWorld_Mining_Tool(v)
end