


--require("data.warfare.edits.entities")
require("data.warfare.edits.items")
require("data.warfare.edits.recipes")

require("data.warfare.armor.normal")
require("data.warfare.armor.modular")

require("data.warfare.ammo.bullet")
require("data.warfare.ammo.grenades")
require("data.warfare.ammo.rocket")

require("data.warfare.walls.walls")

require("data.warfare.radar.radar")

require("data.warfare.vehicles.cars")
require("data.warfare.vehicles.tanks")

require("data.warfare.guns.gun")
require("data.warfare.guns.land-mine")
require("data.warfare.guns.recipe")

require("data.warfare.turrets.bullet")
require("data.warfare.turrets.laser")
require("data.warfare.turrets.grenade")

--require("data.warfare.enemies.units")
--require("data.warfare.enemies.spawner")
