


require("data.chemistry.tech.tech")

require("data.chemistry.intermediates.compounds")
require("data.chemistry.intermediates.elements")
require("data.chemistry.fluids.fluids")

require("data.chemistry.recipe.compounds-atoms")
require("data.chemistry.recipe.switch")
require("data.chemistry.recipe.atoms-compounds")

DyWorld_Add_To_Tech(dy.."chemistry-basic", dy.."recombiner")
DyWorld_Add_To_Tech(dy.."chemistry-basic", dy.."splicer")