


require("data.equipment.edits.items")

if settings.startup["DyWorld_Power"].value then
    require("data.equipment.solar.solar")
end
