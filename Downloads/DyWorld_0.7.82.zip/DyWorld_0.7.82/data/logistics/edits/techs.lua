require "data/prefix"



table.insert(data.raw.technology["logistics-2"].prerequisites,"steel-processing")
