require "data/prefix"
	
for k,v in pairs(Material_Table) do
	DyWorld_Grenade_Turret(v)
end

