

require("data.power.edits.entities")
require("data.power.edits.items")
require("data.power.edits.recipes")

require("data.power.accumulator.accumulator-normal")

require("data.power.solar.solar-normal")

require("data.power.steam.steam-engine")

require("data.power.poles.poles")