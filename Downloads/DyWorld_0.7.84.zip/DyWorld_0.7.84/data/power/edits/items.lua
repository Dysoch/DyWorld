

data.raw.item["solar-panel"].localised_name = {"edits-name.solar-panel"}