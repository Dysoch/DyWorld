require "data/prefix"



data.raw.recipe["boiler"].enabled = false
DyWorld_Add_To_Tech(dy.."steam-energy-1", "boiler")
