

-- Core Module --
require("data.core.data")

-- Metallurgy Module --
require("data.metallurgy.data")

-- Modules Module --
require("data.modules.data")


