require "data/core/functions/prefix"
require "data/core/functions/colors"

data.raw["heat-pipe"]["heat-pipe"].heat_buffer.max_temperature = 5500