

-- Entities
require("data.extraction.entities.electric-drills")
require("data.extraction.entities.pumpjacks")