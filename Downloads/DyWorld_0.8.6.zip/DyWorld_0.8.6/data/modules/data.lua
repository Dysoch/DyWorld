
require("data.modules.speed")
require("data.modules.effectivity")
require("data.modules.productivity")
require("data.modules.pollution-1")
require("data.modules.pollution-2")
require("data.modules.super")