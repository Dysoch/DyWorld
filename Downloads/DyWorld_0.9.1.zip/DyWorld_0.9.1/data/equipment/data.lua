
-- Generators
require("data.equipment.power.tier-1")