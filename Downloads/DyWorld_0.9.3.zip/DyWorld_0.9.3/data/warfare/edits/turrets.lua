require "data/core/functions/prefix"
require "data/core/functions/colors"

if settings.startup["DyWorld_Warfare"].value then


end