require "data/prefix"



table.insert(data.raw.item["pipe-to-ground"].flags, "hidden")
table.insert(data.raw.item["pipe"].flags, "hidden")

table.insert(data.raw.item["transport-belt"].flags, "hidden")
table.insert(data.raw.item["fast-transport-belt"].flags, "hidden")
table.insert(data.raw.item["express-transport-belt"].flags, "hidden")

table.insert(data.raw.item["underground-belt"].flags, "hidden")
table.insert(data.raw.item["fast-underground-belt"].flags, "hidden")
table.insert(data.raw.item["express-underground-belt"].flags, "hidden")

table.insert(data.raw.item["splitter"].flags, "hidden")
table.insert(data.raw.item["fast-splitter"].flags, "hidden")
table.insert(data.raw.item["express-splitter"].flags, "hidden")

table.insert(data.raw.item["storage-tank"].flags, "hidden")
table.insert(data.raw.item["offshore-pump"].flags, "hidden")
table.insert(data.raw.item["pump"].flags, "hidden")

table.insert(data.raw.item["inserter"].flags, "hidden")
table.insert(data.raw.item["long-handed-inserter"].flags, "hidden")
table.insert(data.raw.item["fast-inserter"].flags, "hidden")
table.insert(data.raw.item["filter-inserter"].flags, "hidden")
table.insert(data.raw.item["stack-inserter"].flags, "hidden")
table.insert(data.raw.item["stack-filter-inserter"].flags, "hidden")
