

data.raw.item["solar-panel"].localised_name = {"edits-name.solar-panel"}
table.insert(data.raw.item["medium-electric-pole"].flags, "hidden")