require "data/prefix"



data.raw.recipe["medium-electric-pole"].hidden = true
