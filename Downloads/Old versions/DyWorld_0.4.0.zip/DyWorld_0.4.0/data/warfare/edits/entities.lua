


data.raw.unit["small-biter"].localised_name = {"edits-name.small-biter"}
data.raw.unit["medium-biter"].localised_name = {"edits-name.medium-biter"}
data.raw.unit["big-biter"].localised_name = {"edits-name.big-biter"}
data.raw.unit["behemoth-biter"].localised_name = {"edits-name.behemoth-biter"}
data.raw.unit["small-spitter"].localised_name = {"edits-name.small-spitter"}
data.raw.unit["medium-spitter"].localised_name = {"edits-name.medium-spitter"}
data.raw.unit["big-spitter"].localised_name = {"edits-name.big-spitter"}
data.raw.unit["behemoth-spitter"].localised_name = {"edits-name.behemoth-spitter"}

data.raw.corpse["small-biter-corpse"].localised_name = {"edits-name.small-biter-corpse"}
data.raw.corpse["medium-biter-corpse"].localised_name = {"edits-name.medium-biter-corpse"}
data.raw.corpse["big-biter-corpse"].localised_name = {"edits-name.big-biter-corpse"}
data.raw.corpse["behemoth-biter-corpse"].localised_name = {"edits-name.behemoth-biter-corpse"}
data.raw.corpse["small-spitter-corpse"].localised_name = {"edits-name.small-spitter-corpse"}
data.raw.corpse["medium-spitter-corpse"].localised_name = {"edits-name.medium-spitter-corpse"}
data.raw.corpse["big-spitter-corpse"].localised_name = {"edits-name.big-spitter-corpse"}
data.raw.corpse["behemoth-spitter-corpse"].localised_name = {"edits-name.behemoth-spitter-corpse"}

data.raw["unit-spawner"]["biter-spawner"].localised_name = {"edits-name.biter-spawner"}
data.raw["unit-spawner"]["spitter-spawner"].localised_name = {"edits-name.spitter-spawner"}

data.raw.corpse["biter-spawner-corpse"].localised_name = {"edits-name.biter-spawner-corpse"}
data.raw.corpse["spitter-spawner-corpse"].localised_name = {"edits-name.spitter-spawner-corpse"}