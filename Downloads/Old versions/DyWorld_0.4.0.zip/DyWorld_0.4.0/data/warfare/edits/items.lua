


table.insert(data.raw.item["gun-turret"].flags, "hidden")
table.insert(data.raw.item["laser-turret"].flags, "hidden")

table.insert(data.raw.ammo["firearm-magazine"].flags, "hidden")
table.insert(data.raw.ammo["piercing-rounds-magazine"].flags, "hidden")
table.insert(data.raw.ammo["uranium-rounds-magazine"].flags, "hidden")
table.insert(data.raw.ammo["shotgun-shell"].flags, "hidden")
table.insert(data.raw.ammo["piercing-shotgun-shell"].flags, "hidden")