require "data/prefix"



data.raw.recipe["small-electric-pole"].hidden = true
data.raw.recipe["medium-electric-pole"].hidden = true
data.raw.recipe["big-electric-pole"].hidden = true
