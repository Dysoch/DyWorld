
require("data.modules.speed")
require("data.modules.effectivity")
require("data.modules.productivity")