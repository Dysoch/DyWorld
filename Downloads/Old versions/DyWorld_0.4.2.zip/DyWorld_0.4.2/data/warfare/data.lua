


require("data.warfare.edits.entities")
require("data.warfare.edits.items")
require("data.warfare.edits.recipes")

require("data.warfare.ammo.bullet")

require("data.warfare.turrets.bullet")
require("data.warfare.turrets.laser")