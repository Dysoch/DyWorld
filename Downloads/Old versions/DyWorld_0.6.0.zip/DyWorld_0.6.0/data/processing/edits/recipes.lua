require "data/prefix"



data.raw.recipe["assembling-machine-1"].hidden = true
data.raw.recipe["assembling-machine-2"].hidden = true
data.raw.recipe["assembling-machine-3"].hidden = true
