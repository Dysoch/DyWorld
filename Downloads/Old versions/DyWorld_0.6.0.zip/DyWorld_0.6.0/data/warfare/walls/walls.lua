require "data/prefix"
	
for k,v in pairs(Material_Table) do
	DyWorld_Walls(v)
end