require "data/prefix"
	
for k,v in pairs(Material_Table) do
	DyWorld_Assembling_Machines(v)
end