require "data/prefix"

Data_Table = {
	{
		
	},
}

for k,v in pairs(Data_Table) do
data:extend(
  {
	
  })
end