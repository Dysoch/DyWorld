
require("data.power.entities.boiler")
require("data.power.entities.solar")
require("data.power.entities.accumulator")
require("data.power.entities.steam-engine")
require("data.power.entities.steam-turbine")
require("data.power.entities.nuclear-engines")