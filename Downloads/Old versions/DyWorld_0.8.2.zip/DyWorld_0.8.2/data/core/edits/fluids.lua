require "data/core/functions/prefix"

data.raw.fluid["steam"].max_temperature = 50000