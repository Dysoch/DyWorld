
-- Recipes
require("data.metallurgy.recipes.ore-to-molten")
require("data.metallurgy.recipes.slag-to-molten")
require("data.metallurgy.recipes.molten-to-plate")
require("data.metallurgy.recipes.molten-to-gear")
require("data.metallurgy.recipes.molten-to-cable")
require("data.metallurgy.recipes.molten-to-stick")
require("data.metallurgy.recipes.molten-mixing")