
require("data.warfare.entities.walls")
require("data.warfare.entities.gates")
require("data.warfare.entities.radars")