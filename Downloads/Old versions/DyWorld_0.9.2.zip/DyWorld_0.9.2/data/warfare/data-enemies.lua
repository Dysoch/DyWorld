

require("data.warfare.enemies.dying-explosions")
require("data.warfare.enemies.biters")
require("data.warfare.enemies.spitters")
require("data.warfare.enemies.bases")
require("data.warfare.enemies.worms")