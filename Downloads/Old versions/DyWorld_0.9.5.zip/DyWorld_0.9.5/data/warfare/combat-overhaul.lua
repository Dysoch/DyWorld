
require("data.warfare.combat-overhaul.add-collision")
require("data.warfare.combat-overhaul.vanilla-ammo")
require("data.warfare.combat-overhaul.change-capsules")
require("data.warfare.combat-overhaul.change-projectiles")
require("data.warfare.combat-overhaul.change-guns")
require("data.warfare.combat-overhaul.change-ammo")
require("data.warfare.combat-overhaul.change-turrets")
require("data.warfare.combat-overhaul.turret-change-scripts")