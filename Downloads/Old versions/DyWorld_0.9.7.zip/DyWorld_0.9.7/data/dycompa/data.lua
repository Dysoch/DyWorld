
-- Edits
require("data.dycompa.edits.item-group-change")
require("data.dycompa.edits.mod-changes")
require("data.dycompa.changes.dyworld-core")
require("data.dycompa.changes.dyworld-logistic")
require("data.dycompa.changes.dyworld-processing")
require("data.dycompa.changes.dyworld-power")
require("data.dycompa.changes.dyworld-extraction")
require("data.dycompa.changes.dyworld-warfare")
--require("data.dycompa.changes.dyworld-equipment")
--require("data.dycompa.changes.dyworld-decor")